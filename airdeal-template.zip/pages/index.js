export default function Home() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Bienvenue sur AirDeal ✈️</h1>
      <p>Site en construction — bientôt les meilleurs vols pas chers !</p>
    </div>
  );
}