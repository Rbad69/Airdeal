# AirDeal

Ce projet affichera bientôt des vols à prix réduit grâce à l’IA.